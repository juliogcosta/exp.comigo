package com.eventostec.api.adapter.outbound.storage;

public interface ImageUploadPort {
  //String uploadImage(MultipartFile file);
}
