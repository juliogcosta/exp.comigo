package com.eventostec.api.adapter.inbound.dto;

public record AddressResponseDTO(
    Long id, 
    String city, 
    String state) {
}