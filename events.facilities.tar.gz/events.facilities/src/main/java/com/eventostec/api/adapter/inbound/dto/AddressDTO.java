package com.eventostec.api.adapter.inbound.dto;

public record AddressDTO (
    Long id,
    String city,
    String state) {
}